git add .
git commit -m "saving..."
git push